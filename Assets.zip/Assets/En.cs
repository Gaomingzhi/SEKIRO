﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class En : MonoBehaviour
{
    public Transform pos1;
    public Transform pos2;
    public Collider collider;
    private void Start()
    {
        Off();
        AnimatorOverrideController animatorOverrideController = new AnimatorOverrideController(GetComponent<Animator>().runtimeAnimatorController);

        AnimationEvent animationEvent = new AnimationEvent();
        animationEvent.time = 1f;
        animationEvent.functionName = "On";

        AnimationEvent animationEvent2 = new AnimationEvent();
        animationEvent2.time = 1f + 0.3f / 3f;
        animationEvent2.functionName = "Off";

        animatorOverrideController["attack"].AddEvent(animationEvent);
        animatorOverrideController["attack"].AddEvent(animationEvent2);
    }

    public void On()
    {
        collider.enabled = true;
    }
    public void Off()
    {
        collider.enabled = false;
    }


}
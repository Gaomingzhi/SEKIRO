﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//运动的物体有刚体
public class PL : MonoBehaviour {
    public ParticleSystem particle;
    public ParticleSystem HIT;

    private void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            GetComponent<Animator>().SetBool("idle", false);
            GetComponent<Animator>().SetBool("block",true);

        }
        else
        {
            GetComponent<Animator>().SetBool("idle", true);
            GetComponent<Animator>().SetBool("block", false);
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (other.tag == "en")
        {
            if (GetComponent<Animator>().GetCurrentAnimatorStateInfo(0).IsName("block"))
            {
                particle.Play();
            }
            else
            {
                HIT.Play();
            }
        }
        else
        {
            Debug.Log(other.tag);
        }
    }




}
